import {Facade} from './Facade';

var facade = new Facade();
facade.subsystemOperation();