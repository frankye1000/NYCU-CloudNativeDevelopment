"use strict";
exports.__esModule = true;
var Adapter_1 = require("./Adapter");
var adapter = new Adapter_1.Adapter();
adapter.method('test data');
