"use strict";
exports.__esModule = true;
exports.Adaptee = void 0;
var Adaptee = /** @class */ (function () {
    function Adaptee() {
    }
    Adaptee.prototype.serviceMethod = function (data) {
        console.log('Adaptee Method: ' + data);
    };
    return Adaptee;
}());
exports.Adaptee = Adaptee;
