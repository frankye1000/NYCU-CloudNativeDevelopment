import {Adapter} from './Adapter'

var adapter = new Adapter();
adapter.method('test data');