"use strict";
exports.__esModule = true;
exports.Adapter = void 0;
var Adaptee_1 = require("./Adaptee");
var Adapter = /** @class */ (function () {
    function Adapter() {
    }
    Adapter.prototype.method = function (data) {
        this.adaptee = new Adaptee_1.Adaptee();
        this.adaptee.serviceMethod(data);
    };
    return Adapter;
}());
exports.Adapter = Adapter;
