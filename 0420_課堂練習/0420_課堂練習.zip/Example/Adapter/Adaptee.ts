export class Adaptee{						
		public serviceMethod(data: string): void
		{
				console.log('Adaptee Method: ' + data);
		}
}