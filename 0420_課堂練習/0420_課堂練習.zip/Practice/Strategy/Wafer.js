"use strict";
exports.__esModule = true;
exports.Wafer = void 0;
var Wafer = /** @class */ (function () {
    function Wafer(id, product) {
        this.id = id;
        this.product = product;
    }
    return Wafer;
}());
exports.Wafer = Wafer;
