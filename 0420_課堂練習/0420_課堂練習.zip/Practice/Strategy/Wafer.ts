export class Wafer{
	public id: string;	
	public product: string;
	
	constructor(id:string, product:string){
			this.id = id;			
			this.product = product;
	}
}