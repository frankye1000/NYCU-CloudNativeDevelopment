"use strict";
exports.__esModule = true;
var Wafer_1 = require("./Wafer");
var APC_1 = require("./APC");
var ProcessTool_1 = require("./ProcessTool");
var apc = new APC_1.APC();
var processTool_a = new ProcessTool_1.ProcessTool('A');
var processTool_b = new ProcessTool_1.ProcessTool('B');
//再實作C
var processTool_c = new ProcessTool_1.ProcessTool('C');
var wafer1 = new Wafer_1.Wafer('N12345.00', 'Mobile Phone');
var wafer2 = new Wafer_1.Wafer('N54321.00', 'Personal Computer');
var wafer3 = new Wafer_1.Wafer('N11111.00', 'NoteBook');
//自己加的部分
var wafer4 = new Wafer_1.Wafer('N87878.00', 'NoteBook');
apc.execute(wafer1, processTool_a);
apc.execute(wafer2, processTool_b);
apc.execute(wafer3, processTool_a);
apc.execute(wafer4, processTool_c);
