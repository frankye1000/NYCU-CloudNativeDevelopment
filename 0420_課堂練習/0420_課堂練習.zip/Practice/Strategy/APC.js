"use strict";
exports.__esModule = true;
exports.APC = void 0;
var Adapter_1 = require("./Adapter");
var Adapter_2 = require("./Adapter");
var ProductStrategy_1 = require("./ProductStrategy");
var ProductStrategy_2 = require("./ProductStrategy");
var ProductStrategy_3 = require("./ProductStrategy");
var APC = /** @class */ (function () {
    function APC() {
    }
    APC.prototype.genSubrecipe = function (wafer) {
        this.productStrategy = this.decideProductStrategy(wafer);
        return this.productStrategy.genSubrecipe(wafer);
    };
    APC.prototype.decideProductStrategy = function (wafer) {
        if (wafer.product == 'Mobile Phone') {
            return new ProductStrategy_1.MPStrategy();
        }
        else if (wafer.product == 'Personal Computer') {
            return new ProductStrategy_2.PCStrategy();
        }
        else {
            return new ProductStrategy_3.NBStrategy();
        }
    };
    APC.prototype.execute = function (wafer, processTool) {
        var sr = this.genSubrecipe(wafer);
        if (processTool.toolName == 'A') {
            this.adapter = new Adapter_1.Adapter_A(processTool);
        }
        else if (processTool.toolName == 'B') {
            this.adapter = new Adapter_2.Adapter_B(processTool);
        }
        else {
            // default tool A
            this.adapter = new Adapter_1.Adapter_A(processTool);
        }
        this.adapter.execute(sr);
    };
    return APC;
}());
exports.APC = APC;
