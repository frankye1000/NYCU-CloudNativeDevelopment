"use strict";
exports.__esModule = true;
exports.AnotherAPC = void 0;
var Subrecipe_1 = require("./Subrecipe");
var AnotherAPC = /** @class */ (function () {
    function AnotherAPC() {
    }
    AnotherAPC.prototype.genSubrecipe = function (wafer) {
        var subrecipe;
        if (wafer.genSubrecipeMode == 'ByProductStrategy') {
            if (wafer.product == 'Mobile Phone') {
                subrecipe = new Subrecipe_1.Subrecipe('APC Subrecipe for[' + wafer.id + ']: A+B*(Fn of MobilePhone)');
            }
            else if (wafer.product == 'Personal Computer') {
                subrecipe = new Subrecipe_1.Subrecipe('APC Subrecipe for[' + wafer.id + ']: A+B*(Fn of PersonalComputer)');
            }
            else {
                subrecipe = new Subrecipe_1.Subrecipe('APC Subrecipe for[' + wafer.id + ']: A+B*(Fn of NoteBook)');
            }
        }
        else if (wafer.genSubrecipeMode == 'Recommend') {
            subrecipe = new Subrecipe_1.Subrecipe('Recommend Subrecipe for[' + wafer.id + ']');
        }
        else {
            subrecipe = new Subrecipe_1.Subrecipe('Feedforward Subrecipe for[' + wafer.id + ']');
        }
        return subrecipe;
    };
    AnotherAPC.prototype.execute = function (wafer, processTool) {
        var sr = this.genSubrecipe(wafer);
        if (processTool.toolName == 'A') {
            console.log('(Adapter A process subrecipe for Tool A)');
        }
        else if (processTool.toolName == 'B') {
            console.log('(Adapter B process subrecipe for Tool B)');
        }
        else {
            // default tool A
            console.log('(Adapter A process subrecipe for Tool A)');
        }
        processTool.execute(sr);
    };
    AnotherAPC.prototype.checkSubrecipeSpec = function (subrecipe) {
        console.log('--> check subrecipe spec for ' + subrecipe.name);
    };
    AnotherAPC.prototype.log = function (subrecipe) {
        console.log('--> log subrecipe for ' + subrecipe.name);
    };
    AnotherAPC.prototype.updateAPCModel = function (subrecipe) {
        console.log('--> update APC model for ' + subrecipe.name);
    };
    return AnotherAPC;
}());
exports.AnotherAPC = AnotherAPC;
