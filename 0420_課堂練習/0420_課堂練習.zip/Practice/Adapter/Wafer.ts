export class Wafer{
	public id: string;	
	
	constructor(id:string){
			this.id = id;			
	}
}