"use strict";
exports.__esModule = true;
exports.Subrecipe = void 0;
var Subrecipe = /** @class */ (function () {
    function Subrecipe(name) {
        this.name = name;
    }
    return Subrecipe;
}());
exports.Subrecipe = Subrecipe;
