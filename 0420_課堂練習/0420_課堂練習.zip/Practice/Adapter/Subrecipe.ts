export class Subrecipe {
		public name : String;
		
		constructor(name: String){
				this.name = name;
		}				
}