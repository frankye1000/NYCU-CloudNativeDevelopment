"use strict";
exports.__esModule = true;
exports.Wafer = void 0;
var Wafer = /** @class */ (function () {
    function Wafer(id) {
        this.id = id;
    }
    return Wafer;
}());
exports.Wafer = Wafer;
