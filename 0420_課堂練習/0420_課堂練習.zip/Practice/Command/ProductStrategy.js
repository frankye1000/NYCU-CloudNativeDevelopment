"use strict";
exports.__esModule = true;
exports.NBStrategy = exports.PCStrategy = exports.MPStrategy = void 0;
var Subrecipe_1 = require("./Subrecipe");
var MPStrategy = /** @class */ (function () {
    function MPStrategy() {
    }
    MPStrategy.prototype.genSubrecipe = function (wafer) {
        return new Subrecipe_1.Subrecipe('APC Subrecipe for[' + wafer.id + ']: A+B*(Fn of MobilePhone)+(F2n of MobilePhone)');
    };
    return MPStrategy;
}());
exports.MPStrategy = MPStrategy;
var PCStrategy = /** @class */ (function () {
    function PCStrategy() {
    }
    PCStrategy.prototype.genSubrecipe = function (wafer) {
        return new Subrecipe_1.Subrecipe('APC Subrecipe for[' + wafer.id + ']: A+B*(Fn of PersonalComputer)+(F2n of PersonalComputer)');
    };
    return PCStrategy;
}());
exports.PCStrategy = PCStrategy;
var NBStrategy = /** @class */ (function () {
    function NBStrategy() {
    }
    NBStrategy.prototype.genSubrecipe = function (wafer) {
        return new Subrecipe_1.Subrecipe('APC Subrecipe for[' + wafer.id + ']: A+B*(Fn of NoteBook)+(F2n of NoteBook)');
    };
    return NBStrategy;
}());
exports.NBStrategy = NBStrategy;
